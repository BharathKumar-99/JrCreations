window.onload = function () {
    var de = document.getElementById("LoadingPage");
    de.style.display = 'none';
};