
<script>
    function before(){
        
        document.getElementById("ssj")
        .innerHTML = "You clicked the button, I am new paragraph.";
    }
     
    function afterr(){
        document.getElementById('myImage')
        .src="img/photo2.jpg";
        document.getElementById('message')
        .innerHTML="Bye! GeeksforGeeks people";
    }
</script>